import { createTheme } from '@mui/material/styles';
const theme = createTheme({ palette: { primary: { main: '#6a1b9a' }, secondary: { main: '#00bfa5' } }, typography: { fontFamily: 'Inter, Roboto, Arial' } });
export default theme;
