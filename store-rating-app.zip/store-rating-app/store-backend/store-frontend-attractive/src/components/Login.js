import React, {useState} from 'react';
import API from '../api';
import { TextField, Button, Typography, Alert, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

export default function Login({ setUser }) {
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [error,setError]=useState(''); const [loading,setLoading]=useState(false);
  const navigate = useNavigate();

  const submit = async ()=>{
    try{ setLoading(true); setError(''); const res = await API.post('/auth/login', { email, password }); const { token, user } = res.data; localStorage.setItem('token', token); localStorage.setItem('email', user.email); localStorage.setItem('role', user.role); setUser(user); navigate('/stores'); alert('Login successful!'); }
    catch(err){ setError(err?.response?.data?.message || 'Login failed'); }
    finally{ setLoading(false); }
  };

  return (
    <Box className="center-card">
      <Typography variant="h5" sx={{mb:2}}>Login</Typography>
      {error && <Alert severity="error" sx={{mb:2}}>{error}</Alert>}
      <TextField label="Email" fullWidth sx={{mb:2}} value={email} onChange={e=>setEmail(e.target.value)} />
      <TextField label="Password" type="password" fullWidth sx={{mb:2}} value={password} onChange={e=>setPassword(e.target.value)} />
      <Button variant="contained" color="primary" onClick={submit} disabled={loading}>{loading? 'Please wait...' : 'Login'}</Button>
    </Box>
  );
}
