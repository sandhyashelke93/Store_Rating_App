import React, {useEffect, useState} from 'react';
import API from '../api';
import StoreCard from './StoreCard';
import { Typography } from '@mui/material';

export default function Stores(){
  const [stores,setStores]=useState([]);
  const [loading,setLoading]=useState(false);
  const fetch = async ()=>{ try{ setLoading(true); const res = await API.get('/stores'); setStores(res.data); } catch(e){} finally{ setLoading(false); } };
  useEffect(()=>{ fetch(); },[]);
  return (
    <div>
      <Typography variant="h4" sx={{mb:2}}>Stores</Typography>
      {loading ? <p>Loading...</p> : (
        stores.length === 0 ? <p>No stores found.</p> : stores.map(s=> <StoreCard key={s.id} store={s} />)
      )}
    </div>
  );
}
