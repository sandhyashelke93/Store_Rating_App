# Store Rating Backend (MySQL)

## Setup

1. Copy `.env.example` to `.env` and update DB credentials.
2. Create MySQL database: `CREATE DATABASE store_rating_db;`
3. Install dependencies: `npm install`
4. Seed admin user: `node src/seed.js` (creates admin@example.com / Admin@1234)
5. Run dev server: `npm run dev`

API endpoints:
- POST /api/auth/register
- POST /api/auth/login
- POST /api/stores (admin)
- GET /api/stores
- POST /api/ratings/:storeId (user)
