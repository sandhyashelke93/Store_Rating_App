const express = require('express');
const router = express.Router();
const { Store } = require('../models');
const authenticate = require('../middleware/authMiddleware');
const permit = require('../middleware/roleMiddleware');

router.post('/', authenticate, permit('ADMIN'), async (req, res) => {
  try {
    const store = await Store.create(req.body);
    res.status(201).json(store);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

router.get('/', authenticate, async (req, res) => {
  const stores = await Store.findAll();
  res.json(stores);
});

module.exports = router;
