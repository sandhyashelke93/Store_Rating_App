const express = require('express');
const router = express.Router();
const { Rating, Store } = require('../models');
const authenticate = require('../middleware/authMiddleware');
const permit = require('../middleware/roleMiddleware');

router.post('/:storeId', authenticate, permit('USER'), async (req, res) => {
  const { storeId } = req.params;
  const { rating } = req.body;
  const userId = req.user.id;

  try {
    let rec = await Rating.findOne({ where: { userId, storeId } });
    if (rec) {
      rec.rating = rating;
      await rec.save();
    } else {
      rec = await Rating.create({ userId, storeId, rating });
    }
    const avg = await Rating.findAll({
      where: { storeId },
      attributes: [[Rating.sequelize.fn('AVG', Rating.sequelize.col('rating')), 'avg']]
    });
    await Store.update({ avgRating: avg[0].dataValues.avg }, { where: { id: storeId } });
    res.json({ message: 'Rating saved', avg: avg[0].dataValues.avg });
  } catch (err) { res.status(500).json({ message: err.message }); }
});

module.exports = router;
