const bcrypt = require('bcrypt');
const { sequelize, User } = require('./models');

(async () => {
  await sequelize.sync();
  const hashed = await bcrypt.hash('Admin@1234', 10);
  await User.findOrCreate({
    where: { email: 'admin@example.com' },
    defaults: { name: 'System Administrator Name Here......', password: hashed, role: 'ADMIN' }
  });
  console.log("Admin seeded: admin@example.com / Admin@1234");
  process.exit(0);
})();
