import React from 'react';
export default function Footer(){ return (<div className='footer'>© 2025 Store Rating App — Demo project — contact@storerating.com</div>); }
