import React from 'react';
import { Typography, Card, CardContent, Grid, Link } from '@mui/material';
export default function About(){
  const tech = [
    {name:'React', url:'https://react.dev'}, {name:'Node.js', url:'https://nodejs.org'}, {name:'MySQL', url:'https://www.mysql.com'}, {name:'JWT', url:'https://jwt.io'}, {name:'Material-UI', url:'https://mui.com'}
  ];
  return (
    <div style={{maxWidth:900, margin:'24px auto'}}>
      <Typography variant='h4' sx={{mb:2}}>About Store Rating App</Typography>
      <Typography sx={{mb:2}}>This demo project allows users to rate stores and shows average ratings. It includes Admin and User roles, authentication, and a demo mode for presentation.</Typography>
      <Typography variant='h6' sx={{mt:2}}>Tech Stack</Typography>
      <Grid container spacing={2} sx={{mt:1}}>
        {tech.map(t=> (
          <Grid item key={t.name}><Card sx={{p:1}}><CardContent><Link href={t.url} target='_blank' rel='noreferrer'>{t.name}</Link></CardContent></Card></Grid>
        ))}
      </Grid>
    </div>
  );
}
