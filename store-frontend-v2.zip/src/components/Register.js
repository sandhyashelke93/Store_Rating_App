import React, {useState} from 'react';
import API from '../api';
import { TextField, Button, Typography, Alert, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';
export default function Register(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [address,setAddress]=useState('');
  const [error,setError]=useState(''); const [loading,setLoading]=useState(false); const navigate = useNavigate();
  const submit = async ()=>{ try{ setLoading(true); setError(''); await API.post('/auth/register',{name,email,password,address}); alert('Registered! Login now.'); navigate('/login'); } catch(err){ setError(err?.response?.data?.message || err?.response?.data?.errors?.[0]?.msg || 'Registration failed'); } finally{ setLoading(false); } };
  return (
    <Box className='center-card'>
      <Typography variant='h5' sx={{mb:2}}>Register</Typography>
      {error && <Alert severity='error' sx={{mb:2}}>{error}</Alert>}
      <TextField label='Name (20-60 chars)' fullWidth sx={{mb:2}} value={name} onChange={e=>setName(e.target.value)} />
      <TextField label='Email' fullWidth sx={{mb:2}} value={email} onChange={e=>setEmail(e.target.value)} />
      <TextField label='Password' type='password' fullWidth sx={{mb:2}} value={password} onChange={e=>setPassword(e.target.value)} />
      <TextField label='Address' fullWidth sx={{mb:2}} value={address} onChange={e=>setAddress(e.target.value)} />
      <Button variant='contained' color='primary' onClick={submit} disabled={loading}>{loading? 'Please wait...' : 'Register'}</Button>
    </Box>
  );
}
