import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
export default function Profile(){
  const email = localStorage.getItem('email');
  const role = localStorage.getItem('role');
  return (
    <Card sx={{maxWidth:520, margin:'24px auto', padding:2}}>
      <CardContent>
        <Typography variant='h6'>My Profile</Typography>
        <Typography sx={{mt:1}}>Email: {email}</Typography>
        <Typography>Role: {role}</Typography>
        <Button sx={{mt:2}} variant='contained' href='#' onClick={()=>{localStorage.removeItem('token'); localStorage.removeItem('email'); localStorage.removeItem('role'); window.location.href='/';}}>Logout</Button>
      </CardContent>
    </Card>
  );
}
