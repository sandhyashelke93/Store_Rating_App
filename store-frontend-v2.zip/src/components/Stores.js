import React, {useEffect, useState} from 'react';
import API from '../api';
import { Typography } from '@mui/material';
export default function Stores(){
  const [stores,setStores]=useState([]); const [loading,setLoading]=useState(false);
  const demo = [{id:1,name:'SuperMart',address:'Main Street',img:'https://picsum.photos/seed/s1/600/400',avgRating:4.5},{id:2,name:'MegaStore',address:'Market Ave',img:'https://picsum.photos/seed/s2/600/400',avgRating:3.8},{id:3,name:'City Bazaar',address:'Downtown',img:'https://picsum.photos/seed/s3/600/400',avgRating:5.0}];
  const fetchStores = async ()=>{ try{ setLoading(true); const res = await API.get('/stores'); setStores(res.data); } catch(err){ setStores(demo); } finally{ setLoading(false); } };
  useEffect(()=>{ fetchStores(); },[]);
  return (<div><Typography variant='h4' sx={{mb:2}}>Stores</Typography>{loading? <p>Loading...</p> : (stores.length===0? <p>No stores found.</p> : <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:16}}>{stores.map(s=> (<div key={s.id} style={{background:'#fff',borderRadius:12,padding:12,boxShadow:'0 8px 20px rgba(0,0,0,0.06)'}}><img src={s.img || 'https://picsum.photos/600/400'} style={{width:'100%',height:140,objectFit:'cover',borderRadius:8}} alt={s.name} /><h3 style={{marginTop:8}}>{s.name}</h3><p style={{color:'#666'}}>{s.address}</p><div>{Array.from({length:5}).map((_,i)=> <span key={i} style={{color: i < Math.round(s.avgRating||0) ? '#ffc107' : '#e0e0e0'}}>★</span>)} <span style={{marginLeft:8}}>{(s.avgRating||0).toFixed(1)}</span></div></div>))}</div>)}</div>);
}
