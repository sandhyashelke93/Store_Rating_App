import React, {useState} from 'react';
import API from '../api';
import { FaStar } from 'react-icons/fa';
import { Box, TextField, Button } from '@mui/material';
export default function RateStore(){
  const [storeId,setStoreId]=useState(''); const [rating,setRating]=useState(5); const [loading,setLoading]=useState(false);
  const submit = async ()=>{ try{ setLoading(true); await API.post(`/ratings/${storeId}`, { rating: Number(rating) }); alert('Rating submitted!'); setStoreId(''); setRating(5); } catch(err){ alert(err?.response?.data?.message || 'Failed'); } finally{ setLoading(false); } };
  return (
    <div>
      <h2>Rate Store</h2>
      <Box sx={{display:'flex', gap:2, alignItems:'center', mb:2}}>
        <TextField label='Store ID' value={storeId} onChange={e=>setStoreId(e.target.value)} />
        <div>
          {Array.from({length:5}).map((_,i)=> (<FaStar key={i} size={28} color={i < rating ? '#ffc107' : '#cfcfcf'} style={{cursor:'pointer', marginRight:6}} onClick={()=>setRating(i+1)} />))}
        </div>
      </Box>
      <Button variant='contained' color='primary' onClick={submit} disabled={loading || !storeId}>{loading? 'Please wait...' : 'Submit Rating'}</Button>
    </div>
  );
}
