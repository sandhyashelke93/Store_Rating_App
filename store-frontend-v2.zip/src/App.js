import React, {useEffect, useState} from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import getTheme from './theme';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Switch from '@mui/material/Switch';
import Box from '@mui/material/Box';
import Login from './components/Login';
import Register from './components/Register';
import Stores from './components/Stores';
import RateStore from './components/RateStore';
import AdminCreateStore from './components/AdminCreateStore';
import Profile from './components/Profile';
import About from './components/About';
import Footer from './components/Footer';
export default function App(){
  const [user,setUser] = useState(null);
  const [mode,setMode] = useState('light');
  const navigate = useNavigate();
  useEffect(()=>{ const email=localStorage.getItem('email'); const role=localStorage.getItem('role'); if(email && role) setUser({email,role}); const saved=localStorage.getItem('themeMode'); if(saved) setMode(saved); },[]);
  const theme = getTheme(mode);
  const toggleTheme = ()=>{ const next = mode==='light' ? 'dark' : 'light'; setMode(next); localStorage.setItem('themeMode', next); };
  const logout = ()=>{ localStorage.removeItem('token'); localStorage.removeItem('email'); localStorage.removeItem('role'); setUser(null); navigate('/'); };
  return (
    <ThemeProvider theme={theme}>
      <AppBar position='static' color='primary' elevation={3}>
        <Toolbar sx={{display:'flex', gap:2}}>
          <Typography variant='h6' sx={{mr:2}}>Store Rating</Typography>
          <Button color='inherit' component={Link} to='/'>Home</Button>
          <Button color='inherit' component={Link} to='/stores'>Stores</Button>
          <Button color='inherit' component={Link} to='/rate'>Rate Store</Button>
          {user?.role === 'ADMIN' && <Button color='inherit' component={Link} to='/admin/store'>Create Store</Button>}
          <div style={{flex:1}} />
          <Box sx={{display:'flex', alignItems:'center', mr:2}}>
            <Switch checked={mode==='dark'} onChange={toggleTheme} inputProps={{'aria-label':'toggle theme'}} />
          </Box>
          <Button color='inherit' component={Link} to='/about'>About</Button>
          {!user ? <><Button color='inherit' component={Link} to='/login'>Login</Button><Button color='inherit' component={Link} to='/register'>Register</Button></> :
            <div style={{display:'flex', alignItems:'center', gap:8}}><Typography variant='body1' sx={{opacity:0.9}}>{user.email}</Typography><Button color='inherit' onClick={logout}>Logout</Button></div>
          }
        </Toolbar>
      </AppBar>
      <Container className='app-container'>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/login' element={<Login setUser={setUser}/>}/>
          <Route path='/register' element={<Register/>}/>
          <Route path='/stores' element={<Stores/>}/>
          <Route path='/rate' element={<RateStore/>}/>
          <Route path='/admin/store' element={<AdminCreateStore/>}/>
          <Route path='/profile' element={<Profile/>}/>
          <Route path='/about' element={<About/>}/>
        </Routes>
      </Container>
      <Footer />
    </ThemeProvider>
  );
}
function Home(){
  const demo = [
    {id:1,name:'SuperMart',address:'Main Street',img:'https://picsum.photos/seed/super/600/400',avgRating:4.5},
    {id:2,name:'MegaStore',address:'Market Avenue',img:'https://picsum.photos/seed/mega/600/400',avgRating:3.8},
    {id:3,name:'City Bazaar',address:'Downtown',img:'https://picsum.photos/seed/city/600/400',avgRating:5.0}
  ];
  return (
    <div>
      <div className='header-hero'>
        <Typography variant='h3' sx={{fontWeight:700}}>Welcome to Store Rating</Typography>
        <Typography sx={{mt:1}}>Rate stores, see average ratings, and help others find the best shops.</Typography>
        <div style={{marginTop:16}}><Button variant='contained' color='secondary' component={Link} to='/login'>Login</Button> <Button variant='outlined' color='inherit' component={Link} to='/register' sx={{ml:1}}>Register</Button></div>
      </div>
      <Typography variant='h5' sx={{mt:3, mb:1}}>Featured Stores</Typography>
      <div className='store-grid'>
        {demo.map(s=> (
          <div key={s.id} style={{background:'#fff', borderRadius:12, padding:12, boxShadow:'0 8px 20px rgba(0,0,0,0.06)'}}>
            <img src={s.img} alt={s.name} className='store-thumb' />
            <Typography variant='h6' sx={{mt:1}}>{s.name}</Typography>
            <Typography variant='body2' sx={{color:'#666'}}>{s.address}</Typography>
            <div style={{marginTop:8}}>{Array.from({length:5}).map((_,i)=> <span key={i} style={{color: i < Math.round(s.avgRating) ? '#ffc107' : '#e0e0e0'}}>★</span>)} <span style={{marginLeft:8}}>{s.avgRating.toFixed(1)}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}
