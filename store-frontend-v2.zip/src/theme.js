import { createTheme } from '@mui/material/styles';
const getDesignTokens = (mode = 'light') => ({
  palette: {
    mode,
    primary: { main: mode === 'light' ? '#6a1b9a' : '#9c4dff' },
    secondary: { main: '#00bfa5' },
    background: { default: mode === 'light' ? '#f3e8ff' : '#0b0710', paper: mode === 'light' ? '#fff' : '#121212' }
  },
  typography: { fontFamily: 'Inter, Roboto, Arial, sans-serif' }
});
export default function getTheme(mode){ return createTheme(getDesignTokens(mode)); }
