# Store Frontend V2 (Purple Theme)

This is the attractive frontend (v2) for the Store Rating app. It connects to the backend API at `http://localhost:4000/api` by default.

## Quick Start

1. Ensure your backend is running (in a separate terminal):

```
cd path\to\store-backend
npm run dev
```

2. Install and start this frontend:

```
cd store-frontend-v2
npm install
npm start
```

3. Open http://localhost:3000 in your browser. If port 3000 is busy, accept another port when prompted.

## Demo mode

- Use demo admin credentials on the login page:
  - Email: `admin@demo.com`
  - Password: `Demo@1234`

When used, the app will show demo stores and allow admin actions locally without a backend.
