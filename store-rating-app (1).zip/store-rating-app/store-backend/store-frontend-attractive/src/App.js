import React, { useEffect, useState } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import theme from './theme';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Login from './components/Login';
import Register from './components/Register';
import Stores from './components/Stores';
import RateStore from './components/RateStore';
import AdminCreateStore from './components/AdminCreateStore';

export default function App(){
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(()=>{
    const email = localStorage.getItem('email');
    const role = localStorage.getItem('role');
    if(email && role) setUser({ email, role });
  },[]);

  const logout = ()=>{ localStorage.removeItem('token'); localStorage.removeItem('email'); localStorage.removeItem('role'); setUser(null); navigate('/'); };

  return (
    <ThemeProvider theme={theme}>
      <AppBar position="static" color="primary" elevation={3}>
        <Toolbar sx={{display:'flex', gap:2}}>
          <Typography variant="h6" sx={{flexGrow:0, mr:2}}>Store Rating</Typography>
          <Button color="inherit" component={Link} to="/">Home</Button>
          <Button color="inherit" component={Link} to="/stores">Stores</Button>
          <Button color="inherit" component={Link} to="/rate">Rate Store</Button>
          {user?.role === 'ADMIN' && <Button color="inherit" component={Link} to="/admin/store">Create Store</Button>}
          <div style={{flex:1}} />
          {!user ? (
            <>
              <Button color="inherit" component={Link} to="/login">Login</Button>
              <Button color="inherit" component={Link} to="/register">Register</Button>
            </>
          ) : (
            <div style={{display:'flex', alignItems:'center', gap:8}}>
              <Typography variant="body1" sx={{opacity:0.9}}>{user.email}</Typography>
              <Button color="inherit" onClick={logout}>Logout</Button>
            </div>
          )}
        </Toolbar>
      </AppBar>
      <Container className="app-container">
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/login" element={<Login setUser={setUser} />} />
          <Route path="/register" element={<Register/>} />
          <Route path="/stores" element={<Stores/>} />
          <Route path="/rate" element={<RateStore/>} />
          <Route path="/admin/store" element={<AdminCreateStore />} />
        </Routes>
      </Container>
    </ThemeProvider>
  );
}

function Home(){
  return (
    <div style={{textAlign:'center', padding:40}}>
      <Typography variant="h3" sx={{color:'#6a1b9a', fontWeight:700}}>Store Rating App</Typography>
      <Typography variant="h6" sx={{mt:2, color:'#333'}}>A colorful, modern UI to rate stores and view average ratings.</Typography>
    </div>
  );
}
