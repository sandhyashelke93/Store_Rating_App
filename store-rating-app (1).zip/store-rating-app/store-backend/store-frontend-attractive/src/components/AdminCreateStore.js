import React, {useState} from 'react';
import API from '../api';
import { TextField, Button, Typography, Box } from '@mui/material';

export default function AdminCreateStore(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [address,setAddress]=useState(''); const [loading,setLoading]=useState(false);
  const submit = async ()=>{ try{ setLoading(true); const res = await API.post('/stores', { name, email, address }); alert('Store created: ' + res.data.name); setName(''); setEmail(''); setAddress(''); } catch(err){ alert(err?.response?.data?.message || 'Failed'); } finally{ setLoading(false); } };
  return (
    <Box className="center-card">
      <Typography variant="h5" sx={{mb:2}}>Create Store (Admin)</Typography>
      <TextField label="Name" fullWidth sx={{mb:2}} value={name} onChange={e=>setName(e.target.value)} />
      <TextField label="Email" fullWidth sx={{mb:2}} value={email} onChange={e=>setEmail(e.target.value)} />
      <TextField label="Address" fullWidth sx={{mb:2}} value={address} onChange={e=>setAddress(e.target.value)} />
      <Button variant="contained" color="primary" onClick={submit} disabled={loading}>{loading? 'Please wait...' : 'Create Store'}</Button>
    </Box>
  );
}
