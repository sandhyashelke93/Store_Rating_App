import React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { FaStar } from 'react-icons/fa';

export default function StoreCard({ store }) {
  const avg = Math.round((store.avgRating || 0));
  return (
    <Card sx={{mb:2, boxShadow:3, borderRadius:2}}>
      <CardContent>
        <Typography variant="h6">{store.name}</Typography>
        <Typography variant="body2" sx={{color:'#555'}}>{store.address}</Typography>
        <div style={{marginTop:8}}>
          {Array.from({length:5}).map((_,i)=>(
            <FaStar key={i} color={i < avg ? '#ffc107' : '#e0e0e0'} />
          ))}
          <span style={{marginLeft:8, color:'#333'}}>{(store.avgRating||0).toFixed(1)}</span>
        </div>
      </CardContent>
    </Card>
  );
}
