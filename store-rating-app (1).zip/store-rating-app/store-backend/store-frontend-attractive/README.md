Store Frontend Attractive (Material-UI) - Run: cd folder, npm install, npm start. Backend must run at http://localhost:4000
Admin: admin@example.com / Admin@1234
