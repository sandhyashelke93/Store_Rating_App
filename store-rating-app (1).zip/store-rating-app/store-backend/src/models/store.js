const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Store = sequelize.define('Store', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(200), allowNull: false },
    email: { type: DataTypes.STRING(180), allowNull: true },
    address: { type: DataTypes.STRING(400), allowNull: true },
    ownerId: { type: DataTypes.INTEGER, allowNull: true },
    avgRating: { type: DataTypes.FLOAT, defaultValue: 0 }
  }, {
    tableName: 'stores',
    timestamps: true
  });

  return Store;
};
