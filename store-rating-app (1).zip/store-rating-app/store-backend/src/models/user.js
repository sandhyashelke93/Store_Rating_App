const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(60), allowNull: false },
    email: { type: DataTypes.STRING(180), allowNull: false, unique: true },
    password: { type: DataTypes.STRING(255), allowNull: false },
    address: { type: DataTypes.STRING(400), allowNull: true },
    role: { type: DataTypes.ENUM('ADMIN','USER','STORE_OWNER'), allowNull: false, defaultValue: 'USER' }
  }, {
    tableName: 'users',
    timestamps: true
  });

  return User;
};
