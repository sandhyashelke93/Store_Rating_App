const sequelize = require('../config/db');
const UserModel = require('./user');
const StoreModel = require('./store');
const RatingModel = require('./rating');

const User = UserModel(sequelize);
const Store = StoreModel(sequelize);
const Rating = RatingModel(sequelize);

User.hasMany(Store, { foreignKey: 'ownerId', as: 'ownedStores' });
Store.belongsTo(User, { foreignKey: 'ownerId', as: 'owner' });

User.hasMany(Rating, { foreignKey: 'userId' });
Rating.belongsTo(User, { foreignKey: 'userId' });

Store.hasMany(Rating, { foreignKey: 'storeId' });
Rating.belongsTo(Store, { foreignKey: 'storeId' });

const initDb = async () => {
  await sequelize.sync({ alter: true });
};

module.exports = { sequelize, User, Store, Rating, initDb };
